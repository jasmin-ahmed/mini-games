// creates an array and passes the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Wie lange dauerte das lange 19. Jahrhundert?",
    answer: "1789 - 1914",
    options: [
      "1714 - 1989",
      "1789 - 1914",
      "1716 - 1912"
    ]
  },
    {
    numb: 2,
    question: "Wer war für den ersten vollständigen österreichischen Liegenschaftskataster verantwortlich?",
    answer: "Franz I.",
    options: [
      "Josef II.",
      "Leopold II.",
      "Franz I."
    ]
  },
    {
    numb: 3,
    question: "Um 1850 hatte der Grazer Raum eine Bevölkerung von 65.000 Menschen. Bei der Volkszählung 1910 waren es...",
    answer: "193.000 Einwohner",
    options: [
      "193.000 Einwohner",
      "330.000 Einwohner",
      "127.000 Einwohner"
    ]
  },
    {
    numb: 4,
    question: "Wie viele Einwohner hat Graz laut Stand 2021?",
    answer: "291.134 Einwohner",
    options: [
      "312.736 Einwohner",
      "413.645 Einwohner",
      "291.134 Einwohner"
    ]
  },
    {
    numb: 5,
    question: "Die erste österreichische Bauordnung wurde am 18.04.1820 für welche Städte erlassen?",
    answer: "Linz, Salzburg",
    options: [
      "Wien, Klagenfurt",
      "Linz, Salzburg",
      "Innsbruck, Wien"
    ]
  },
];