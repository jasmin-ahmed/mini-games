const textElement = document.getElementById('text')
const optionButtonsElement = document.getElementById('option-buttons')

let state = {}

function startGame() {
  state = {}
  showTextNode(1)
}

function showTextNode(textNodeIndex) {
  const textNode = textNodes.find(textNode => textNode.id === textNodeIndex)
  textElement.innerText = textNode.text
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild)
  }

  textNode.options.forEach(option => {
    if (showOption(option)) {
      const button = document.createElement('button')
      button.innerText = option.text
      button.classList.add('btn')
      button.addEventListener('click', () => selectOption(option))
      optionButtonsElement.appendChild(button)
    }
  })
}

function showOption(option) {
  return option.requiredState == null || option.requiredState(state)
}

function selectOption(option) {
  const nextTextNodeId = option.nextText
  if (nextTextNodeId <= 0) {
    return startGame()
  }
  state = Object.assign(state, option.setState) // Objects and states could be added to make the game more complex! See report -> Conclusion.
  showTextNode(nextTextNodeId)
}

const textNodes = [ // Game logic illustrated and explained in report (Figure 1).
  {
    id: 1,
    text: 'In seinem Reisebericht aus dem Jahr 1838 schreibt Joseph Alexander Wonsidler über Graz: "Aus Trümmern des grauen Alterthums, wovon bis in unsere Zeit noch Spuren geblieben, erhob sich nach und nach diese freundliche Stadt." Welches der "theils niedlichen, theils prächtigen" Gebäude möchtest du als "wißbegierige(r) Fremde" zuerst besuchen?',
    options: [
      {
        text: 'Joanneum', // Answer A (Figure 1).
        nextText: 2
      },
      {
        text: 'Ständisches Zeughaus', // Answer B. 
        nextText: 3
      }
    ]
  },
  {
    id: 2,
    text: 'Du bewunderst die reichen Bücher-, Naturalien- und Alterthümerschätze des Joanneums. Gut gefallen dir auch einige Gemälde der Bildergalerie! Wo geht es als nächstes hin?',
    options: [
      {
        text: 'Hauptplatz', // Answer Aa.
        nextText: 4
      },
      {
        text: 'Burgtor', // Answer Bb.
        nextText: 5
      },
    ]
  },
  {
    id: 3,
    text: 'Du suchst Einlass zum bedeutenden und merkwürdigen Waffenvorrat des Landeszeughauses. Wo geht es auf deiner genussreichen Wanderung durch die steirische Hauptstadt nun hin?',
    options: [
      {
        text: 'Hauptplatz', // Answer Aa.
        nextText: 4
      },
      {
        text: 'Burgtor', // Answer Bb.
        nextText: 5
      },
    ]
  },
  {
    id: 4,
    text: 'Du spazierst zum Hauptplatz und dir fällt vor allem das schöne Rathaus auf! Es wurde durch Christian Stadler erbaut und im Jahr 1807 vollendet. Dort befinden sich auch über die Hauptfronte die Statuen der Clio und Themis neben dem Wappenpanther und einigen Genien mit Gerichtsattributen. Diese sind vom Bildhauer Gagon. Möchtest du das Burgtor als nächstes besuchen?',
    options: [
      {
        text: 'Ja, gerne!', // Answer Aaa. -> Answer Aa. 
        nextText: 5
      },
      {
        text: 'Nein, ich bin müde und habe für heute genug gesehen.', // Answer Bbb. -> End (Restart).
        nextText: -1
      }
    ]
  },
  {
    id: 5,
    text: 'An der Burg, vor der du nun stehst, hausten Babenberger sowie viele Söhne Habsburgs! Dort erblickte auch Kaiser Ferdinand das Leben. Dort befindet sich auch das Tor. Im selben Eck der schönen steirischen Hauptstadt findest du den Dom, von Friedrich dem Friedsamen im Jahr 1456 erbaut. Möchtest du den Hauptplatz als nächstes besuchen?',
    options: [
      {
        text: 'Ja, gerne!', // Answer Aaa -> Answer Bb. 
        nextText: 4
      },
      {
        text: 'Nein, ich bin müde und habe für heute genug gesehen.', // Answer Bbb -> End (Restart).
        nextText: -1
      }
    ]
  }
]
startGame()